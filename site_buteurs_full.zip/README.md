Site "Classement — Meilleurs Buteurs & Statistiques" (Mode Sombre)

Contenu du ZIP :
- index.html   -> page principale (ouvrir dans le navigateur)
- README.md    -> ce fichier

Instructions :
1. Dézippe le fichier `site_buteurs_full.zip`.
2. Ouvre `index.html` dans ton navigateur (double-clic).
3. Utilise le bouton "+ Ajouter" pour créer des joueurs ou "Importer CSV".
   Format CSV attendu : name,club,goals,assists,matches,yellow,red,year
4. Les données sont sauvegardées localement dans localStorage (dans ton navigateur).
5. Pour publier en ligne, crée un dépôt GitHub, ajoute ces fichiers et active GitHub Pages (branche main).
